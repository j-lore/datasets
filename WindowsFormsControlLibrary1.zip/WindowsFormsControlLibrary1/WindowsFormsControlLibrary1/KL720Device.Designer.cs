﻿namespace WindowsFormsControlLibrary1
{
    partial class KL720Device
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_ScanDevice = new System.Windows.Forms.Button();
            this.btn_ImageFile = new System.Windows.Forms.Button();
            this.btn_ModelFile = new System.Windows.Forms.Button();
            this.btn_Start = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_Result = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_ScanDevice
            // 
            this.btn_ScanDevice.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btn_ScanDevice.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn_ScanDevice.Location = new System.Drawing.Point(78, 81);
            this.btn_ScanDevice.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_ScanDevice.Name = "btn_ScanDevice";
            this.btn_ScanDevice.Size = new System.Drawing.Size(136, 30);
            this.btn_ScanDevice.TabIndex = 0;
            this.btn_ScanDevice.Text = "Scan Device";
            this.btn_ScanDevice.UseVisualStyleBackColor = false;
            this.btn_ScanDevice.Click += new System.EventHandler(this.btn_ScanDevice_Click);
            // 
            // btn_ImageFile
            // 
            this.btn_ImageFile.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btn_ImageFile.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn_ImageFile.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_ImageFile.Location = new System.Drawing.Point(170, 127);
            this.btn_ImageFile.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_ImageFile.Name = "btn_ImageFile";
            this.btn_ImageFile.Size = new System.Drawing.Size(136, 30);
            this.btn_ImageFile.TabIndex = 1;
            this.btn_ImageFile.Text = "Image";
            this.btn_ImageFile.UseVisualStyleBackColor = false;
            this.btn_ImageFile.Click += new System.EventHandler(this.btn_ImageFolder_Click);
            // 
            // btn_ModelFile
            // 
            this.btn_ModelFile.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btn_ModelFile.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn_ModelFile.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_ModelFile.Location = new System.Drawing.Point(18, 127);
            this.btn_ModelFile.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_ModelFile.Name = "btn_ModelFile";
            this.btn_ModelFile.Size = new System.Drawing.Size(136, 30);
            this.btn_ModelFile.TabIndex = 2;
            this.btn_ModelFile.Text = "Model ";
            this.btn_ModelFile.UseVisualStyleBackColor = false;
            this.btn_ModelFile.Click += new System.EventHandler(this.btn_ModelFolder_Click);
            // 
            // btn_Start
            // 
            this.btn_Start.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btn_Start.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn_Start.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_Start.Location = new System.Drawing.Point(323, 127);
            this.btn_Start.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_Start.Name = "btn_Start";
            this.btn_Start.Size = new System.Drawing.Size(136, 30);
            this.btn_Start.TabIndex = 3;
            this.btn_Start.Text = "Start";
            this.btn_Start.UseVisualStyleBackColor = false;
            this.btn_Start.Click += new System.EventHandler(this.btn_start_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(234, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(166, 25);
            this.label1.TabIndex = 4;
            this.label1.Text = "KL720 Inference";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // btn_Result
            // 
            this.btn_Result.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btn_Result.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btn_Result.Location = new System.Drawing.Point(476, 127);
            this.btn_Result.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_Result.Name = "btn_Result";
            this.btn_Result.Size = new System.Drawing.Size(136, 30);
            this.btn_Result.TabIndex = 5;
            this.btn_Result.Text = "Result";
            this.btn_Result.UseVisualStyleBackColor = false;
            this.btn_Result.Click += new System.EventHandler(this.btn_ResultFolder_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(19, 86);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 19);
            this.label3.TabIndex = 8;
            this.label3.Text = "Step 1";
            // 
            // KL720Device
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btn_Result);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_Start);
            this.Controls.Add(this.btn_ModelFile);
            this.Controls.Add(this.btn_ImageFile);
            this.Controls.Add(this.btn_ScanDevice);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "KL720Device";
            this.Size = new System.Drawing.Size(633, 185);
            this.Load += new System.EventHandler(this.UserControl1_Load_1);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_ScanDevice;
        private System.Windows.Forms.Button btn_ImageFile;
        private System.Windows.Forms.Button btn_ModelFile;
        private System.Windows.Forms.Button btn_Start;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_Result;
        private System.Windows.Forms.Label label3;
    }
}
