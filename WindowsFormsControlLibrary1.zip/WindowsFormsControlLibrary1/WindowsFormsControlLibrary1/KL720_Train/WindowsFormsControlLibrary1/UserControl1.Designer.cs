﻿namespace WindowsFormsControlLibrary1
{
    partial class UserControl
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 元件設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.numericUpDown_gpu = new System.Windows.Forms.NumericUpDown();
            this.textBox_ProjectName = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.numericUpDown_epoch = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.numericUpDown_batch = new System.Windows.Forms.NumericUpDown();
            this.button_Train = new System.Windows.Forms.Button();
            this.button_Inference = new System.Windows.Forms.Button();
            this.button_2onnx = new System.Windows.Forms.Button();
            this.checkBox_MobileNetv2 = new System.Windows.Forms.CheckBox();
            this.Backone = new System.Windows.Forms.GroupBox();
            this.checkBox_Yolov5 = new System.Windows.Forms.CheckBox();
            this.checkBox_ResNet18 = new System.Windows.Forms.CheckBox();
            this.checkBox_ResNet50 = new System.Windows.Forms.CheckBox();
            this.button_2nef = new System.Windows.Forms.Button();
            this.button_DataFolder = new System.Windows.Forms.Button();
            this.numericUpDown_ImageSize = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_gpu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_epoch)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_batch)).BeginInit();
            this.Backone.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_ImageSize)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(244, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(130, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Train Model";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label2.Location = new System.Drawing.Point(111, 107);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 19);
            this.label2.TabIndex = 2;
            this.label2.Text = "gpu";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label3.Location = new System.Drawing.Point(70, 177);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 19);
            this.label3.TabIndex = 4;
            this.label3.Text = "batch-size";
            // 
            // numericUpDown_gpu
            // 
            this.numericUpDown_gpu.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.numericUpDown_gpu.Increment = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.numericUpDown_gpu.Location = new System.Drawing.Point(172, 105);
            this.numericUpDown_gpu.Maximum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDown_gpu.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            -2147483648});
            this.numericUpDown_gpu.Name = "numericUpDown_gpu";
            this.numericUpDown_gpu.Size = new System.Drawing.Size(81, 27);
            this.numericUpDown_gpu.TabIndex = 6;
            this.numericUpDown_gpu.ValueChanged += new System.EventHandler(this.numericUpDown1_gpu);
            // 
            // textBox_ProjectName
            // 
            this.textBox_ProjectName.Location = new System.Drawing.Point(153, 63);
            this.textBox_ProjectName.Name = "textBox_ProjectName";
            this.textBox_ProjectName.Size = new System.Drawing.Size(100, 25);
            this.textBox_ProjectName.TabIndex = 7;
            this.textBox_ProjectName.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label4.Location = new System.Drawing.Point(45, 69);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(103, 19);
            this.label4.TabIndex = 8;
            this.label4.Text = "Project Name";
            // 
            // numericUpDown_epoch
            // 
            this.numericUpDown_epoch.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.numericUpDown_epoch.Location = new System.Drawing.Point(172, 139);
            this.numericUpDown_epoch.Name = "numericUpDown_epoch";
            this.numericUpDown_epoch.Size = new System.Drawing.Size(81, 27);
            this.numericUpDown_epoch.TabIndex = 11;
            this.numericUpDown_epoch.ValueChanged += new System.EventHandler(this.numericUpDown2_Epoch);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label6.Location = new System.Drawing.Point(98, 141);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(51, 19);
            this.label6.TabIndex = 12;
            this.label6.Text = "epoch";
            // 
            // numericUpDown_batch
            // 
            this.numericUpDown_batch.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.numericUpDown_batch.Location = new System.Drawing.Point(172, 172);
            this.numericUpDown_batch.Maximum = new decimal(new int[] {
            6400,
            0,
            0,
            0});
            this.numericUpDown_batch.Name = "numericUpDown_batch";
            this.numericUpDown_batch.Size = new System.Drawing.Size(81, 27);
            this.numericUpDown_batch.TabIndex = 13;
            this.numericUpDown_batch.ValueChanged += new System.EventHandler(this.numericUpDown1_Batch);
            // 
            // button_Train
            // 
            this.button_Train.BackColor = System.Drawing.Color.Turquoise;
            this.button_Train.Enabled = false;
            this.button_Train.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_Train.Location = new System.Drawing.Point(484, 99);
            this.button_Train.Name = "button_Train";
            this.button_Train.Size = new System.Drawing.Size(113, 30);
            this.button_Train.TabIndex = 14;
            this.button_Train.Text = "Train";
            this.button_Train.UseVisualStyleBackColor = false;
            this.button_Train.Click += new System.EventHandler(this.button2_Train);
            // 
            // button_Inference
            // 
            this.button_Inference.BackColor = System.Drawing.Color.Turquoise;
            this.button_Inference.Enabled = false;
            this.button_Inference.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_Inference.Location = new System.Drawing.Point(484, 135);
            this.button_Inference.Name = "button_Inference";
            this.button_Inference.Size = new System.Drawing.Size(113, 30);
            this.button_Inference.TabIndex = 15;
            this.button_Inference.Text = "Inference";
            this.button_Inference.UseVisualStyleBackColor = false;
            this.button_Inference.Click += new System.EventHandler(this.button_Inference_Click);
            // 
            // button_2onnx
            // 
            this.button_2onnx.BackColor = System.Drawing.Color.Turquoise;
            this.button_2onnx.Enabled = false;
            this.button_2onnx.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_2onnx.Location = new System.Drawing.Point(484, 171);
            this.button_2onnx.Name = "button_2onnx";
            this.button_2onnx.Size = new System.Drawing.Size(113, 30);
            this.button_2onnx.TabIndex = 16;
            this.button_2onnx.Text = "To onnx";
            this.button_2onnx.UseVisualStyleBackColor = false;
            this.button_2onnx.Click += new System.EventHandler(this.button_2onnx_Click);
            // 
            // checkBox_MobileNetv2
            // 
            this.checkBox_MobileNetv2.AutoSize = true;
            this.checkBox_MobileNetv2.Location = new System.Drawing.Point(17, 36);
            this.checkBox_MobileNetv2.Name = "checkBox_MobileNetv2";
            this.checkBox_MobileNetv2.Size = new System.Drawing.Size(121, 23);
            this.checkBox_MobileNetv2.TabIndex = 17;
            this.checkBox_MobileNetv2.Text = "MobileNetv2";
            this.checkBox_MobileNetv2.UseVisualStyleBackColor = true;
            this.checkBox_MobileNetv2.CheckedChanged += new System.EventHandler(this.checkBox1_mobilenetv2_CheckedChanged);
            // 
            // Backone
            // 
            this.Backone.Controls.Add(this.checkBox_Yolov5);
            this.Backone.Controls.Add(this.checkBox_ResNet18);
            this.Backone.Controls.Add(this.checkBox_ResNet50);
            this.Backone.Controls.Add(this.checkBox_MobileNetv2);
            this.Backone.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Backone.Location = new System.Drawing.Point(269, 63);
            this.Backone.Name = "Backone";
            this.Backone.Size = new System.Drawing.Size(209, 171);
            this.Backone.TabIndex = 18;
            this.Backone.TabStop = false;
            this.Backone.Text = "Choose Backbone";
            // 
            // checkBox_Yolov5
            // 
            this.checkBox_Yolov5.AutoSize = true;
            this.checkBox_Yolov5.Location = new System.Drawing.Point(17, 140);
            this.checkBox_Yolov5.Name = "checkBox_Yolov5";
            this.checkBox_Yolov5.Size = new System.Drawing.Size(79, 23);
            this.checkBox_Yolov5.TabIndex = 20;
            this.checkBox_Yolov5.Text = "Yolov5";
            this.checkBox_Yolov5.UseVisualStyleBackColor = true;
            this.checkBox_Yolov5.CheckedChanged += new System.EventHandler(this.checkBox4_Yolov5_CheckedChanged);
            // 
            // checkBox_ResNet18
            // 
            this.checkBox_ResNet18.AutoSize = true;
            this.checkBox_ResNet18.Location = new System.Drawing.Point(17, 72);
            this.checkBox_ResNet18.Name = "checkBox_ResNet18";
            this.checkBox_ResNet18.Size = new System.Drawing.Size(99, 23);
            this.checkBox_ResNet18.TabIndex = 19;
            this.checkBox_ResNet18.Text = "ResNet18";
            this.checkBox_ResNet18.UseVisualStyleBackColor = true;
            this.checkBox_ResNet18.CheckedChanged += new System.EventHandler(this.checkBox2_ResNet18_CheckedChanged);
            // 
            // checkBox_ResNet50
            // 
            this.checkBox_ResNet50.AutoSize = true;
            this.checkBox_ResNet50.Location = new System.Drawing.Point(17, 108);
            this.checkBox_ResNet50.Name = "checkBox_ResNet50";
            this.checkBox_ResNet50.Size = new System.Drawing.Size(99, 23);
            this.checkBox_ResNet50.TabIndex = 18;
            this.checkBox_ResNet50.Text = "ResNet50";
            this.checkBox_ResNet50.UseVisualStyleBackColor = true;
            this.checkBox_ResNet50.CheckedChanged += new System.EventHandler(this.checkBox3_ResNet50_CheckedChanged);
            // 
            // button_2nef
            // 
            this.button_2nef.BackColor = System.Drawing.Color.Turquoise;
            this.button_2nef.Enabled = false;
            this.button_2nef.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_2nef.Location = new System.Drawing.Point(484, 207);
            this.button_2nef.Name = "button_2nef";
            this.button_2nef.Size = new System.Drawing.Size(113, 30);
            this.button_2nef.TabIndex = 19;
            this.button_2nef.Text = "To nef";
            this.button_2nef.UseVisualStyleBackColor = false;
            this.button_2nef.Click += new System.EventHandler(this.button_2nef_Click);
            // 
            // button_DataFolder
            // 
            this.button_DataFolder.BackColor = System.Drawing.Color.Turquoise;
            this.button_DataFolder.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.button_DataFolder.Location = new System.Drawing.Point(484, 63);
            this.button_DataFolder.Name = "button_DataFolder";
            this.button_DataFolder.Size = new System.Drawing.Size(113, 30);
            this.button_DataFolder.TabIndex = 20;
            this.button_DataFolder.Text = "Data";
            this.button_DataFolder.UseVisualStyleBackColor = false;
            this.button_DataFolder.Click += new System.EventHandler(this.button1_Data);
            // 
            // numericUpDown_ImageSize
            // 
            this.numericUpDown_ImageSize.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.numericUpDown_ImageSize.Location = new System.Drawing.Point(173, 205);
            this.numericUpDown_ImageSize.Maximum = new decimal(new int[] {
            6400,
            0,
            0,
            0});
            this.numericUpDown_ImageSize.Name = "numericUpDown_ImageSize";
            this.numericUpDown_ImageSize.Size = new System.Drawing.Size(80, 27);
            this.numericUpDown_ImageSize.TabIndex = 22;
            this.numericUpDown_ImageSize.ValueChanged += new System.EventHandler(this.numericUpDown4_Image_size);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.Location = new System.Drawing.Point(64, 210);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(85, 19);
            this.label5.TabIndex = 21;
            this.label5.Text = "image-size";
            // 
            // UserControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.Controls.Add(this.numericUpDown_ImageSize);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.button_DataFolder);
            this.Controls.Add(this.button_2nef);
            this.Controls.Add(this.button_2onnx);
            this.Controls.Add(this.button_Inference);
            this.Controls.Add(this.button_Train);
            this.Controls.Add(this.numericUpDown_batch);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.numericUpDown_epoch);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBox_ProjectName);
            this.Controls.Add(this.numericUpDown_gpu);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Backone);
            this.Name = "UserControl";
            this.Size = new System.Drawing.Size(638, 257);
            this.Load += new System.EventHandler(this.UserControl1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_gpu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_epoch)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_batch)).EndInit();
            this.Backone.ResumeLayout(false);
            this.Backone.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_ImageSize)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown numericUpDown_gpu;
        private System.Windows.Forms.TextBox textBox_ProjectName;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown numericUpDown_epoch;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown numericUpDown_batch;
        private System.Windows.Forms.Button button_Train;
        private System.Windows.Forms.Button button_Inference;
        private System.Windows.Forms.Button button_2onnx;
        private System.Windows.Forms.CheckBox checkBox_MobileNetv2;
        private System.Windows.Forms.GroupBox Backone;
        private System.Windows.Forms.CheckBox checkBox_ResNet18;
        private System.Windows.Forms.CheckBox checkBox_ResNet50;
        private System.Windows.Forms.Button button_2nef;
        private System.Windows.Forms.Button button_DataFolder;
        private System.Windows.Forms.NumericUpDown numericUpDown_ImageSize;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.CheckBox checkBox_Yolov5;
    }
}
