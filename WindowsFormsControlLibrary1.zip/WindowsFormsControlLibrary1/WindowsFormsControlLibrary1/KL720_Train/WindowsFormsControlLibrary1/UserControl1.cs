﻿/**using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Reflection;
using System.IO;
using System.Diagnostics;

namespace WindowsFormsControlLibrary1
{
    public partial class UserControl: System.Windows.Forms.UserControl
    {
        private int gpu;
        private int epoch;
        private int batch;
        private int imagesize;
        private string backbone;
        private string projectName;
        private string dataFolderPath;
        private string trainexpPath;
        private string folderPath = @"C:\KL720_Control\classification\auo";
        private string PthPath = @"C:\KL720_Control\classification\mobilenetv2.pth";


        public UserControl()
        {
            InitializeComponent();
        }
        private void UserControl1_Load(object sender, EventArgs e)
        {

        }
        
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            projectName = textBox_ProjectName.Text;
        }
        private void numericUpDown1_gpu(object sender, EventArgs e)
        {
           gpu = (int)numericUpDown_gpu.Value;
        }
        private void numericUpDown2_Epoch(object sender, EventArgs e)
        {
            epoch = (int)numericUpDown_epoch.Value;
        }
        private void numericUpDown1_Batch(object sender, EventArgs e)
        {
            batch = (int)numericUpDown_batch.Value;
        }
        private void numericUpDown4_Image_size(object sender, EventArgs e)
        {
            imagesize = (int)numericUpDown_ImageSize.Value;
        }


        private void checkBox1_mobilenetv2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox_MobileNetv2.Checked)
            {
                UncheckOtherCheckBoxes(checkBox_MobileNetv2);
                backbone = "mobilenetv2"; 
            }
        }
        private void checkBox2_ResNet18_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox_ResNet18.Checked)
            {
                UncheckOtherCheckBoxes(checkBox_ResNet18);
                backbone = "resnet18";
            }
        }
        private void checkBox3_ResNet50_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox_ResNet50.Checked)
            {
                UncheckOtherCheckBoxes(checkBox_ResNet50);
                backbone = "resnet50";;
            }
        }

        private void Backone_Enter(object sender, EventArgs e)
        {

        }

        private void UncheckOtherCheckBoxes(CheckBox checkedBox)
        {
            foreach (Control control in Backone.Controls)
            {
                if (control is CheckBox checkBox && checkBox != checkedBox)
                {
                    checkBox.Checked = false;
                }
            }
        }
        
        private void button1_Data(object sender, EventArgs e)
        {
            CreateDataFolder();
           
        }

        private void CreateDataFolder()
        {
            dataFolderPath = Path.Combine(folderPath, projectName, "data");
            MessageBox.Show(dataFolderPath);

            // Check if the folder exists
            if (!Directory.Exists(dataFolderPath))
            {
                // Create the data folder
                Directory.CreateDirectory(dataFolderPath);

                // Open the folder in File Explorer
                Process.Start("explorer.exe", dataFolderPath);

                // Define the subdirectories to be created
                string[] subdirectories = new[]
                {
                Path.Combine(dataFolderPath, "train", "OK"),
                Path.Combine(dataFolderPath, "train", "NG"),
                Path.Combine(dataFolderPath, "val", "OK"),
                Path.Combine(dataFolderPath, "val", "NG")
            };

                try
                {
                    // Create each subdirectory
                    foreach (var subdir in subdirectories)
                    {
                        Directory.CreateDirectory(subdir);
                    }

                    // MessageBox.Show("Data folder and subfolders created successfully.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error creating data folders: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                // Open the existing folder in File Explorer
                Process.Start("explorer.exe", dataFolderPath);
            }
        }

        private void button2_Train(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(dataFolderPath))
            {
                MessageBox.Show("Data folder path is not set.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Declare trainFolderPath outside the if-else blocks
            string trainFolderPath = null;

            // Determine the backbone type and set the appropriate folder path
            if (backbone == "mobilenetv2")
            {
                trainFolderPath = Path.Combine(folderPath, projectName,  "train_mobilenetv2");
            }
            else if (backbone == "resnet18")
            {
                trainFolderPath = Path.Combine(folderPath, projectName,  "train_resnet18");
            }
            else if (backbone == "resnet50")
            {
                trainFolderPath = Path.Combine(folderPath, projectName, "train_resnet50");
            }
            else
            {
                MessageBox.Show("Invalid backbone specified.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Get the highest existing exp folder number
            int expNumber = 1;
            while (Directory.Exists(Path.Combine(trainFolderPath, "exp" + expNumber)))
            {
                expNumber++;
            }

            // Construct the new exp folder path
            string uniqueExpFolderPath = Path.Combine(trainFolderPath, "exp" + expNumber);
            uniqueExpFolderPath = uniqueExpFolderPath.Replace("\\\\", "\\"); // Replace double backslashes with single backslashes
            Directory.CreateDirectory(uniqueExpFolderPath);
            // Construct the command string
            string pythonScriptPath = @"C:\KL720_Control\classification\train.py";
            //dataFolderPath = dataFolderPath.Replace("\\\\", "\\"); // Replace double backslashes with single backslashes
            
            string command = $"python \"{pythonScriptPath}\" --gpu {gpu} --freeze-backbone 1 --backbone {backbone} --early-stop 1 --snapshot {PthPath} --snapshot-path \"{uniqueExpFolderPath}\" --epoch {epoch} --batch-size {batch} --image-size {imagesize} --data_dir \"{dataFolderPath}\"";
            // Start the process
            ProcessStartInfo startInfo = new ProcessStartInfo();
            startInfo.FileName = "cmd.exe";
            startInfo.Arguments = $"/K \"{command}\"";
            startInfo.UseShellExecute = false;
            startInfo.CreateNoWindow = false;

            try
            {
                Process.Start(startInfo);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error executing command: " + ex.Message);
            }
            Process.Start("explorer.exe", uniqueExpFolderPath);
            trainexpPath = uniqueExpFolderPath;
            
        }


        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button_Inference_Click(object sender, EventArgs e)
        {
            string inferenceFolderPath = Path.Combine(folderPath, projectName, "inference");
            Directory.CreateDirectory(inferenceFolderPath);
            // Get the highest existing exp folder number
            /////////////////*int expNumber = 1;
            while (Directory.Exists(Path.Combine(inferenceFolderPath, "exp" + expNumber)))
            {
                expNumber++;
            }

            // Construct the new exp folder path
            string uniqueExpName = "exp" + expNumber;
            string uniqueExpFolderPath = Path.Combine(inferenceFolderPath, uniqueExpName);

            Directory.CreateDirectory(uniqueExpFolderPath);
            Process.Start("explorer.exe", uniqueExpFolderPath);*///////////////////////
/*string pythonScriptPath = @"C:\KL720_Control\classification\inference.py";
string bestpthPath = Path.Combine(trainexpPath, "model_ft_best.pth");
string classid = @"C:\KL720_Control\classification\eval_utils\class_id.json";
string command = $"python \"{pythonScriptPath}\" --gpu {gpu} --backbone {backbone} --snapshot \"{bestpthPath}\" --class_id_path \"{classid}\" --img-path \"{inferenceFolderPath}\"";
// Start the process
ProcessStartInfo startInfo = new ProcessStartInfo();
startInfo.FileName = "cmd.exe";
startInfo.Arguments = $"/K \"{command}\"";
startInfo.UseShellExecute = false;
startInfo.CreateNoWindow = false;

try
{
    Process.Start(startInfo);
}
catch (Exception ex)
{
    MessageBox.Show("Error executing command: " + ex.Message);
}
Process.Start("explorer.exe", inferenceFolderPath);
}

private void button_2onnx_Click_2onnx(object sender, EventArgs e)
{
string pythonScriptPath = @"C:\KL720_Control\classification\pytorch2onnx.py";
string projectPath = Path.Combine(folderPath, projectName);
string OnnxPath = Path.Combine(folderPath, projectName,"best.onnx");
string bestpthPath = Path.Combine(trainexpPath, "model_ft_best.pth");
string command = $"python \"{pythonScriptPath}\" --backbone {backbone} --num_classes 2 --snapshot \"{bestpthPath}\" --save-path {OnnxPath}";
ProcessStartInfo startInfo = new ProcessStartInfo();
startInfo.FileName = "cmd.exe";
startInfo.Arguments = $"/K \"{command}\"";
startInfo.UseShellExecute = false;
startInfo.CreateNoWindow = false;

try
{
    Process.Start(startInfo);
}
catch (Exception ex)
{
    MessageBox.Show("Error executing command: " + ex.Message);
}

Process.Start("explorer.exe", projectPath);
}

private void checkBox1_CheckedChanged(object sender, EventArgs e)
{

}

private void button_2nef_Click(object sender, EventArgs e)
{
string url = "http://localhost:8180/#toolchain_webgui_all_in_one";

try
{
    // Open the URL in the default web browser
    Process.Start(new ProcessStartInfo
    {
        FileName = url,
        UseShellExecute = true
    });
}
catch (Exception ex)
{
    // Handle any errors that occur
    MessageBox.Show("Error opening the link: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
}
}
}
}
*/

using System;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Diagnostics;
using System.Windows.Forms;

namespace WindowsFormsControlLibrary1
{
    public partial class UserControl : System.Windows.Forms.UserControl
    {
        private int gpu;
        private int epoch;
        private int batch;
        private int imagesize;
        private string backbone;
        private string projectName;
        private string dataFolderPath;
        private string trainexpPath;
        private const string folderPath = @"C:\KL720_EXE\classification\auo";
        private const string pythonScriptBasePath = @"C:\KL720_EXE\classification\";
        private const string explorerPath = "explorer.exe";

        public UserControl()
        {
            InitializeComponent();
        }

        private void UserControl1_Load(object sender, EventArgs e)
        {
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            projectName = textBox_ProjectName.Text;
        }

        private void numericUpDown1_gpu(object sender, EventArgs e)
        {
            gpu = (int)numericUpDown_gpu.Value;
        }

        private void numericUpDown2_Epoch(object sender, EventArgs e)
        {
            epoch = (int)numericUpDown_epoch.Value;
        }

        private void numericUpDown1_Batch(object sender, EventArgs e)
        {
            batch = (int)numericUpDown_batch.Value;
        }

        private void numericUpDown4_Image_size(object sender, EventArgs e)
        {
            imagesize = (int)numericUpDown_ImageSize.Value;
        }

        private void checkBox1_mobilenetv2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox_MobileNetv2.Checked)
            {
                UncheckOtherCheckBoxes(checkBox_MobileNetv2);
                backbone = "mobilenetv2";
            }
        }

        private void checkBox4_Yolov5_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox_Yolov5.Checked)
            {
                UncheckOtherCheckBoxes(checkBox_Yolov5);
                backbone = "Yolov5";
            }
        }

        private void checkBox2_ResNet18_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox_ResNet18.Checked)
            {
                UncheckOtherCheckBoxes(checkBox_ResNet18);
                backbone = "resnet18";
            }
        }

        private void checkBox3_ResNet50_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox_ResNet50.Checked)
            {
                UncheckOtherCheckBoxes(checkBox_ResNet50);
                backbone = "resnet50";
            }
        }

        private void UncheckOtherCheckBoxes(CheckBox checkedBox)
        {
            foreach (Control control in Backone.Controls)
            {
                if (control is CheckBox checkBox && checkBox != checkedBox)
                {
                    checkBox.Checked = false;
                }
            }
        }

        private void button1_Data(object sender, EventArgs e)
        {
            CreateDataFolder();
            button_Train.Enabled = true;
        }

        private void CreateDataFolder()
        {
            dataFolderPath = Path.Combine(folderPath, projectName, "data");
            MessageBox.Show(dataFolderPath);

            if (!Directory.Exists(dataFolderPath))
            {
                Directory.CreateDirectory(dataFolderPath);
                Process.Start(explorerPath, dataFolderPath);

                string[] subdirectories = new[]
                {
                    Path.Combine(dataFolderPath, "train", "OK"),
                    Path.Combine(dataFolderPath, "train", "NG"),
                    Path.Combine(dataFolderPath, "val", "OK"),
                    Path.Combine(dataFolderPath, "val", "NG")
                };

                try
                {
                    foreach (var subdir in subdirectories)
                    {
                        Directory.CreateDirectory(subdir);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error creating data folders: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                Process.Start(explorerPath, dataFolderPath);
            }
        }

        private void button2_Train(object sender, EventArgs e)
        {
            button_Inference.Enabled = true;
            if (string.IsNullOrEmpty(dataFolderPath))
            {
                MessageBox.Show("Data folder path is not set.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string trainFolderPath = GetTrainFolderPath();

            if (trainFolderPath == null)
            {
                MessageBox.Show("Invalid backbone specified.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string PthPath = Path.Combine(pythonScriptBasePath, $"{backbone}.pth");
            string uniqueExpFolderPath = GetUniqueExpFolderPath(trainFolderPath);
            Directory.CreateDirectory(uniqueExpFolderPath);

            string command = $"python \"{Path.Combine(pythonScriptBasePath, "train.py")}\" --gpu {gpu} --freeze-backbone 1 --backbone {backbone} --early-stop 1 --snapshot {PthPath} --snapshot-path \"{uniqueExpFolderPath}\" --epoch {epoch} --batch-size {batch} --image-size {imagesize} --data_dir \"{dataFolderPath}\"";

            ExecuteCommand(command);
            Process.Start(explorerPath, uniqueExpFolderPath);
            trainexpPath = uniqueExpFolderPath;



           
            string modelPath = Path.Combine(uniqueExpFolderPath, "model_ft_best.pth");
            while (!File.Exists(modelPath))
            {
                System.Threading.Thread.Sleep(1000); // Sleep for 1 second before checking again
            }
            string evalResult = evaluation(uniqueExpFolderPath);
            MessageBox.Show(evalResult, "Evaluation Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
          
            // Run the evaluation once the file is available
            
        }

        private string evaluation(string uniqueExpFolderPath)
        {
            // Construct the command for evaluation
            string evalScriptPath = Path.Combine(pythonScriptBasePath, "eval.py");
            string snapshotPath = Path.Combine(uniqueExpFolderPath, "model_ft_best.pth");
            string dataDir = Path.Combine(dataFolderPath, "val"); // Assuming validation data is in a subfolder called 'val'
            string command = $"python \"{evalScriptPath}\" --gpu {gpu} --backbone {backbone} --snapshot \"{snapshotPath}\" --data-dir \"{dataDir}\"";

            try
            {
                var processInfo = new ProcessStartInfo("cmd.exe", "/c " + command)
                {
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    UseShellExecute = false,
                    CreateNoWindow = true
                };

                using (var process = Process.Start(processInfo))
                {
                    using (var reader = process.StandardOutput)
                    {
                        string result = reader.ReadToEnd();
                        process.WaitForExit();

                        if (process.ExitCode != 0)
                        {
                            using (var errorReader = process.StandardError)
                            {
                                string error = errorReader.ReadToEnd();
                                result += "\nError: " + error;
                            }
                        }

                        return result;
                    }
                }
            }
            catch (Exception ex)
            {
                return "Error: " + ex.Message;
            }
        }

        private string GetTrainFolderPath()
        {
            switch (backbone)
            {
                case "mobilenetv2":
                    return Path.Combine(folderPath, projectName, "train_mobilenetv2");
                case "resnet18":
                    return Path.Combine(folderPath, projectName, "train_resnet18");
                case "resnet50":
                    return Path.Combine(folderPath, projectName, "train_resnet50");
                default:
                    return null;
            }
        }

        private string GetUniqueExpFolderPath(string trainFolderPath)
        {
            int expNumber = 1;
            while (Directory.Exists(Path.Combine(trainFolderPath, "exp" + expNumber)))
            {
                expNumber++;
            }

            return Path.Combine(trainFolderPath, "exp" + expNumber);
        }

        private void ExecuteCommand(string command)
        {
            ProcessStartInfo startInfo = new ProcessStartInfo
            {
                FileName = "cmd.exe",
                Arguments = $"/K \"{command}\"",
                UseShellExecute = false,
                CreateNoWindow = false
            };

            try
            {
                Process.Start(startInfo);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error executing command: " + ex.Message);
            }
        }

        /*private void button_Inference_Click(object sender, EventArgs e)
        {
            string inferenceFolderPath = Path.Combine(folderPath, projectName, "inference");
            Directory.CreateDirectory(inferenceFolderPath);

            string bestpthPath = Path.Combine(trainexpPath, "model_ft_best.pth");
            string classid = Path.Combine(pythonScriptBasePath, @"eval_utils\class_id.json");
            string command = $"python \"{Path.Combine(pythonScriptBasePath, "inference.py")}\" --gpu {gpu} --backbone {backbone} --snapshot \"{bestpthPath}\" --class_id_path \"{classid}\" --img-path \"{inferenceFolderPath}\" --image-size {imagesize}";

            ExecuteCommand(command);
            Process.Start(explorerPath, inferenceFolderPath);
        }*/
        private void button_Inference_Click(object sender, EventArgs e)
        {
            button_2onnx.Enabled = true;
            string inferenceFolderPath = Path.Combine(folderPath, projectName, "inference");

            if (!Directory.Exists(inferenceFolderPath))
            {
                Directory.CreateDirectory(inferenceFolderPath);
                Process.Start(explorerPath, inferenceFolderPath);
            }
            else
            {
                string bestpthPath = Path.Combine(trainexpPath, "model_ft_best.pth");
                string classid = Path.Combine(pythonScriptBasePath, @"eval_utils\class_id.json");
                string command = $"python \"{Path.Combine(pythonScriptBasePath, "inference.py")}\" --gpu {gpu} --backbone {backbone} --snapshot \"{bestpthPath}\" --class_id_path \"{classid}\" --img-path \"{inferenceFolderPath}\" --image-size {imagesize}";

                ExecuteCommand(command);
                //Process.Start(explorerPath, inferenceFolderPath);
            }
        }


        private void button_2onnx_Click(object sender, EventArgs e)
        {
            button_2nef.Enabled = true;
            string onnxPath = Path.Combine(trainexpPath, "best.onnx");
            string bestpthPath = Path.Combine(trainexpPath, "model_ft_best.pth");
            string command = $"python \"{Path.Combine(pythonScriptBasePath, "pytorch2onnx.py")}\" --backbone {backbone} --num_classes 2 --snapshot \"{bestpthPath}\" --save-path {onnxPath}";

            ExecuteCommand(command);
            Process.Start(explorerPath, trainexpPath);
        }

        private void button_2nef_Click(object sender, EventArgs e)
        {
            string url = "http://localhost:8180/#toolchain_webgui_all_in_one";

            try
            {
                Process.Start(new ProcessStartInfo
                {
                    FileName = url,
                    UseShellExecute = true
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error opening the link: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {
            string packagePath1 = @"C:\KL720_EXE\classification\backups\libs\scipy-1.5.4-cp36-cp36m-win_amd64.whl";
            InstallPythonPackage(packagePath1);
            string packagePath2 = @"C:\KL720_EXE\classification\backups\libs\matplotlib-3.3.4-cp36-cp36m-win32.whl";
            InstallPythonPackage(packagePath2);
            string command1 = $"docker pull kneron/toolchain:latest";
            ExecuteCommand(command1);
            string command2 = $"docker run -t -d -p 8180:8180 --name toolchain_webgui -w /workspace kneron/toolchain:latest /workspace/webgui/runWebGUI.sh";
            ExecuteCommand(command2);
        }

        private void InstallPythonPackage(string packagePath)
        {
            ProcessStartInfo startInfo = new ProcessStartInfo
            {
                FileName = "cmd.exe",
                Arguments = $"/K python -m pip install \"{packagePath}\"",
                UseShellExecute = false,
                CreateNoWindow = false
            };

            try
            {
                using (Process cmdProcess = Process.Start(startInfo))
                {
                    cmdProcess.WaitForExit(); // Wait for the process to exit before continuing
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        
    }
}

