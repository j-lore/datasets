﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;


namespace WindowsFormsControlLibrary1
{
    public partial class KL720Device : UserControl
    {
        public KL720Device()
        {
            InitializeComponent();
        }

        private void btn_ScanDevice_Click(object sender, EventArgs e)
        {
            //string currentDirectory = Directory.GetCurrentDirectory();
            //string pythonScriptPath = Path.Combine(currentDirectory, "kneron_plus","python","auo","ScanDevices.py");
            // Path to your Python script
            string pythonScriptPath = @"C:\KL720_EXE\kneron_plus\python\auo\ScanDevices.py";

            // Execute Python script using CMD
            ProcessStartInfo startInfo = new ProcessStartInfo();
            startInfo.FileName = "cmd.exe";
            startInfo.Arguments = $"/C python \"{pythonScriptPath}\"";
            startInfo.UseShellExecute = false;
            startInfo.RedirectStandardOutput = true;
            startInfo.CreateNoWindow = true;

            using (Process process = Process.Start(startInfo))
            {
                // Read the output from CMD
                using (System.IO.StreamReader reader = process.StandardOutput)
                {
                    string result = reader.ReadToEnd();
                    MessageBox.Show(result); // Display result in MessageBox
                }
            }
        }

        private void btn_ImageFolder_Click(object sender, EventArgs e)
        {
            string folderPath = @"C:\KL720_EXE\kneron_plus\python\auo\Input_Image";
            // Check if the folder exists
            if (Directory.Exists(folderPath))
            {
                // Open the folder in File Explorer
                Process.Start("explorer.exe", folderPath);
            }
            else
            {
                // Folder does not exist, display an error message
                MessageBox.Show("The folder does not exist.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_ModelFolder_Click(object sender, EventArgs e)
        {
            string folderPath = @"C:\KL720_EXE\kneron_plus\python\auo\Input_Model";
            // Check if the folder exists
            if (Directory.Exists(folderPath))
            {
                // Open the folder in File Explorer
                Process.Start("explorer.exe", folderPath);
            }
            else
            {
                // Folder does not exist, display an error message
                MessageBox.Show("The folder does not exist.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void UserControl1_Load(object sender, EventArgs e)
        {

        }

        private void btn_start_Click(object sender, EventArgs e)
        {
            //string currentDirectory = Directory.GetCurrentDirectory();
            //string pythonScriptPath = Path.Combine(currentDirectory, "kneron_plus", "python", "auo", "A.py");
            // Path to your Python script
            string pythonScriptPath = @"C:\KL720_EXE\kneron_plus\python\auo\A.py";

            // Execute Python script using CMD
            ProcessStartInfo startInfo = new ProcessStartInfo();
            startInfo.FileName = "cmd.exe";
            startInfo.Arguments = $"/K python \"{pythonScriptPath}\""; 
            startInfo.UseShellExecute = false;
            startInfo.CreateNoWindow = false; 

            try
            {
                Process.Start(startInfo);
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {
            string packagePath = @"C:\KL720_EXE\kneron_plus\python\package\windows\KneronPLUS-2.2.0-py3-none-any.whl";
            InstallPythonPackage(packagePath);
            string pythonScriptPath = @"C:\KL720_EXE\kneron_plus\python\auo\InstallDriverWindows.py";
            ExecutePythonScript(pythonScriptPath);
        }

        private void InstallPythonPackage(string packagePath)
        {
            ProcessStartInfo startInfo = new ProcessStartInfo
            {
                FileName = "cmd.exe",
                Arguments = $"/K python -m pip install \"{packagePath}\"",
                UseShellExecute = false,
                CreateNoWindow = false
            };

            try
            {
                using (Process cmdProcess = Process.Start(startInfo))
                {
                    cmdProcess.WaitForExit(); // Wait for the process to exit before continuing
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }


        }

        private void ExecutePythonScript(string pythonScriptPath)
        {

            ProcessStartInfo startInfo = new ProcessStartInfo();
            startInfo.FileName = "cmd.exe";
            startInfo.Verb = "runasuser";
            startInfo.Arguments = $"/K python \"{pythonScriptPath}\" --target KL720";
            startInfo.UseShellExecute = false;
            startInfo.CreateNoWindow = false;

            try
            {
                using (Process cmdProcess = Process.Start(startInfo))
                {
                    cmdProcess.WaitForExit(); // Wait for the process to exit before continuing
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
        }

        private void UserControl1_Load_1(object sender, EventArgs e)
        {

        }


        private void btn_ResultFolder_Click(object sender, EventArgs e)
        {
            string folderPath = @"C:\KL720_EXE\kneron_plus\python\auo\Result";
            // Check if the folder exists
            if (Directory.Exists(folderPath))
            {
                // Open the folder in File Explorer
                Process.Start("explorer.exe", folderPath);
            }
            else
            {
                // Folder does not exist, display an error message
                MessageBox.Show("The folder does not exist.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
